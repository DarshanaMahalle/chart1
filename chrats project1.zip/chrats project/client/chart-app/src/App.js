import { useState,useEffect } from 'react';
import './App.css';
import { Chart } from './components/Chart';
import FormComp from './components/FormComp';

function App() {
  const [step,setStep]=useState(100)
  const [targetD,setTargetD]=useState(100)
 
  const [data,setData] =useState( {
    labels: ['Steps completed', 'Remaining steps'],
    datasets: [
      {
        label: '# of Votes',
        data: [step,targetD],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
        ],
        borderWidth: 1,
      },
    ],
  });

  useEffect(()=>{
    setData((prevValues)=>{
      let newVal={...prevValues}
       newVal.datasets[0].data[0]=(parseInt(step));
       newVal.datasets[0].data[1]=(parseInt(targetD)-step);
      return newVal
    })
  },[step,targetD])


//fetch data from mongo
  const [chartData,setChartData]=useState()
  useEffect(()=>{
     fetchData();
   //  console.log('chart data in use effect'+chartData)
  },[])

  async function fetchData(){
      const data=await fetch('http://localhost:5050/');
      const json=await data.json();
      
     // console.log('chard data updated ')
      return json
  }

console.log(data)

  return (

    <div className="d-flex" >
        <FormComp setData={setData} setStep={setStep} setTargetD={setTargetD} step={step} targetD={targetD}/>
        <Chart data={data} />
    </div>
  );
}

export default App;
