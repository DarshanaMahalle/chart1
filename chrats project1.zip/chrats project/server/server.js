const express=require('express');
const mongoose=require('mongoose');

const app=express();

//corns used for connecting localhost:3000 react with localhost:5000 node.js server 
const cors=require('cors');
app.use(cors())



// //mongoose connect
// mongoose.connect("mongodb://localhost:27017/chartDb").
// then(()=>{console.log("mongo connected")})    
// .catch(err=>{console.log("mongo err ",err)});

// Connect to MongoDB using Mongoose
mongoose.connect('mongodb://localhost:27017/chartDb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});


//importing mongoose model 
const chartSchema=new mongoose.Schema({
    username:{type:String},
    steps:Number,
    target:Number
})

//create model
const Chart=mongoose.model("Chart",chartSchema);

//to tell app that json data is going to be received to server
app.use(express.json())
app.use(express.urlencoded({ extended: true }));


app.get('/',async(req,res)=>{


   

    const present=await Chart.find({username:'aman'})
    console.log('present')
    console.log(present)
    if(present.length===0){
        const chart=new Chart({
            username:'aman',
            steps:10,
            target:10
        })
        const saveDetails= await chart.save();
        console.log('data saved')
    }

    const chartData=await Chart.find({});
    res.json(chartData)
   // res.send(JSON.stringify(chartData))
    console.log(chartData)
})

async function addFirstEntry(){
    console.log('start')
    const present=await Chart.find({username:'aman'})

    if(!present){
        const chart=new Chart({
            username:'aman',
            steps:10,
            target:10
        })
        const saveDetails= await chart.save();
        console.log('data saved')
    }
   
}

addFirstEntry();

app.post('/',async(req,res)=>{

    console.log(req.body)
    const {step ,target}=req.body

   try{
        const updated={steps:step,target:target}
        const someDate=await Chart.findOneAndUpdate({username:'aman'},{steps:step,target:target})
        console.log('value updated')
        
    }catch{
        res.json({status:'failed'})
    }

    // try{
    //     const {step ,target}=req.body
    //     const chart=new Chart({
    //         username:'aman',
    //         steps:parseInt(step),
    //         target:parseInt(target)
    //     })
    //     const saveDetails= await chart.save();
    //     res.json(saveDetails)
    // }catch{
    //     res.json({status:'failed'})
    // }
    
   
})



app.listen(5050,()=>{
    console.log('server started');
})