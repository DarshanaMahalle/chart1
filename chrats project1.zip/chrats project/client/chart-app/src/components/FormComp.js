import { useEffect, useState } from 'react';
import axios from 'axios'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form'

function FormComp({setData,setStep,setTargetD,step,targetD}) {

//   async function subData(event){
//     event.preventDefault();
//     const requestOption={
//         method:'POST',
//         headers:{
//             'Content-Type': 'application/json'
//         },
//         body: JSON.stringify(
//             { 
//                 step:step,
//                 target:targetD 
        
//         })
//     }
//     const response=await fetch('http://localhost:5050/',requestOption)
//    const data = await response.json();
//    console.log(data.status)
// }

  const [commentText,setCommentText]=useState('');
  async function  subData(e){
    e.preventDefault();
    try {
      console.log('button pressed')
      setCommentText('Data has been added to database')
      const formData={step:step,target:targetD}
      const response = await axios.post('http://localhost:5050/', formData);
      console.log('data saved to db'); // Response from the server with saved user data
    } catch (error) {
      console.error('Error sending POST request:', error);
    }
    
  }




  return (
    <div className='w-25 ' style={{margin:'130px',border:'2px solid aqua', padding:"50px",backgroundColor:"#E8FFCE"}}>
      <Form action='post' onSubmit={subData}>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Total steps completed</Form.Label>
              <Form.Control type="number" placeholder="Enter Steps" 
                  onChange={(event)=>{
                       // changeSteps(event.target.value);
                       setStep(event.target.value);
                   }}/>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label>Set Target for a day</Form.Label>
              <Form.Control type="number" placeholder="Set Target" 
              onChange={(event)=>{
                // changeSteps(event.target.value);
                setTargetD(event.target.value);
            }}/>
            </Form.Group>
            <Button variant="primary" type="submit" >
              Save to Database
            </Button>
            <div style={{color:'purple',marginTop:'20px'}}>
            <h4>{commentText}</h4>
            </div>
            
          </Form>
    </div>
  )
}

export default FormComp